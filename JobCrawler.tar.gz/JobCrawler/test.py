# coding=utf-8

import numpy as np
import pandas as pd

def cut_word(word, method):
    if method == 'bottom':
        length = len(word)
        if(word.find('万') == -1):
            if(word.find('以下') != -1):
                # XX千以下
                postion = word.find('以下')
                bottomSalary = str(word[:(postion-3)])
            elif (word.find('以上') != -1):
                postion = word.find('以上')
                bottomSalary = str(float(word[:postion-3]))
            else:
                # XX千/月
                postion = word.find('-')
                bottomSalary = str(float(word[:(postion)]))
        else:
            if(word.find('年') == -1):
                if(word.find('以下') != -1):
                    # XX万以下
                    postion = word.find('以下')
                    bottomSalary = str(float(word[:(postion-3)]) * 10)
                elif (word.find('以上') != -1):
                    # XX万以上
                    postion = word.find('以上')
                    bottomSalary= str(float(word[:postion-3]) * 10)
                elif (word.find('+') != -1):
                    # XX万+
                    postion = word.find('+')
                    bottomSalary = str(float(word[:(postion)]) * 10)
                else:
                    # XX万/月
                    postion = word.find('-')
                    bottomSalary = str(float(word[:(postion)]) * 10)
                
            else:
                if(word.find('以下') != -1):
                    # XX万以下/年
                    postion = word.find('以下')
                    bottomSalary = str(float(word[:(postion-3)]) / 1.2)
                elif(word.find('以上') != -1):
                    postion = word.find('以上')
                    bottomSalary = str(float(word[:postion-3]) / 1.2)
                elif (word.find('+') != -1):
                    # XX万+
                    postion = word.find('+')
                    bottomSalary = str(float(word[:(postion)]) / 1.2)
                else:
                    # XX万/年
                    postion = word.find('-')
                    bottomSalary = word[:(postion)]
                    bottomSalary = str(float(bottomSalary) / 1.2)
        return bottomSalary

    if method == 'top':
        length = len(word)
        if(word.find('万') == -1):
            if(word.find('以下') != -1):
                # XX千以下
                postion = word.find('以下')
                topSalary = str(float(word[:(postion-3)]))
            elif (word.find('以上') != -1):
                postion = word.find('以上')
                topSalary = str(float(word[:postion-3]))
            else:
                # XX千/月
                postion = word.find('-')
                topSalary = str(float(word[(postion+1):(length-7)]))
        else:
            if(word.find('年') == -1):
                if(word.find('以下') != -1):
                    # XX万以下
                    postion = word.find('以下')
                    topSalary = str(float(word[:(postion-3)]) * 10)
                elif (word.find('以上') != -1):
                    # XX万以上
                    postion = word.find('以上')
                    topSalary = str(float(word[:postion-3]) * 10)
                else:
                    # XX万/月
                    postion = word.find('-')
                    topSalary = str(float(word[(postion+1):(length-7)]) * 10)
                
            else:
                if(word.find('以下') != -1):
                    # XX万以下/年
                    postion = word.find('以下')
                    topSalary = str(float(word[:(postion-3)]) / 1.2)
                elif (word.find('以上') != -1):
                    # XX万以上一年
                    postion = word.find('以上')
                    topSalary = str(float(word[:postion-3]) / 1.2)
                elif (word.find('+') != -1):
                    # XX万+
                    postion = word.find('+')
                    topSalary = str(float(word[:(postion)]) / 1.2)
                else:
                    # XX万/年
                    postion = word.find('-')
                    topSalary = word[(postion+1):(length-7)]
                    topSalary = str(int(topSalary) / 1.2)
        return topSalary

if __name__ == "__main__": 
    df = pd.read_csv(r'../Data/job.csv')
    df = df.dropna(axis=0)
    df_dirty_salary = df[df['salary'].str.contains(r'(小时|天)+')]
    df_dirty_job_name = df[df['job_name'].str.contains(r'(\*|在家|试用|体验|无需|无须|试玩|红包)+')]
    df_dirty = pd.concat([df_dirty_salary, df_dirty_job_name])
    df.drop(df_dirty.index)
    df_clean = df.drop(df_dirty.index)
    df_clean['bottomSalary'] = df_clean.salary.apply(cut_word, method='bottom')
    df_clean['topSalary'] = df_clean.salary.apply(cut_word, method='bottom')
    df_clean.to_csv(r'../Data/job_clean.csv')