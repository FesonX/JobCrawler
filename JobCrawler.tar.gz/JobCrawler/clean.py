import numpy as np
import pandas as pd

df = pd.read_csv(r'PycharmProjects/JobCrawler/job.csv')

df_dirty_salary = df[df['salary'].str.contains(r'(小时|天)+')]

df_dirty_job_name = df[df['job_name'].str.contains(r'(\*|在家|试用|体验|无需|无须|试玩|红包)+')]

df_dirty = pd.concat([df_dirty_salary, df_dirty_job_name])

df.drop(df_dirty.index)

df_clean = df.drop(df_dirty.index)

df_clean