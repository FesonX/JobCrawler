# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
import re
from scrapy.exceptions import DropItem
import sys

reload(sys)
sys.setdefaultencoding('utf8')


class jobCrawlerPipeline(object):

    def cut_word(self, word, method):
        if method == 'bottom':
            length = len(word)
            if (word.find('万') == -1):
                if (word.find('以下') != -1):
                    # XX千以下
                    postion = word.find('以下')
                    bottomSalary = str(word[:(postion - 3)])
                elif (word.find('以上') != -1):
                    postion = word.find('以上')
                    bottomSalary = str(float(word[:postion - 3]))
                else:
                    # XX千/月
                    postion = word.find('-')
                    bottomSalary = str(float(word[:(postion)]))
            else:
                if (word.find('年') == -1):
                    if (word.find('以下') != -1):
                        # XX万以下
                        postion = word.find('以下')
                        bottomSalary = str(float(word[:(postion - 3)]) * 10)
                    elif (word.find('以上') != -1):
                        # XX万以上
                        postion = word.find('以上')
                        bottomSalary = str(float(word[:postion - 3]) * 10)
                    elif (word.find('+') != -1):
                        # XX万+
                        postion = word.find('+')
                        bottomSalary = str(float(word[:(postion)]) * 10)
                    else:
                        # XX万/月
                        postion = word.find('-')
                        bottomSalary = str(float(word[:(postion)]) * 10)

                else:
                    if (word.find('以下') != -1):
                        # XX万以下/年
                        postion = word.find('以下')
                        bottomSalary = str(float(word[:(postion - 3)]) / 1.2)
                    elif (word.find('以上') != -1):
                        postion = word.find('以上')
                        bottomSalary = str(float(word[:postion - 3]) / 1.2)
                    elif (word.find('+') != -1):
                        # XX万+
                        postion = word.find('+')
                        bottomSalary = str(float(word[:(postion)]) / 1.2)
                    else:
                        # XX万/年
                        postion = word.find('-')
                        bottomSalary = word[:(postion)]
                        bottomSalary = str(float(bottomSalary) / 1.2)
            return bottomSalary

        if method == 'top':
            length = len(word)
            if (word.find('万') == -1):
                if (word.find('以下') != -1):
                    # XX千以下
                    postion = word.find('以下')
                    topSalary = str(float(word[:(postion - 3)]))
                elif (word.find('以上') != -1):
                    postion = word.find('以上')
                    topSalary = str(float(word[:postion - 3]))
                else:
                    # XX千/月
                    postion = word.find('-')
                    topSalary = str(float(word[(postion + 1):(length - 7)]))
            else:
                if (word.find('年') == -1):
                    if (word.find('以下') != -1):
                        # XX万以下
                        postion = word.find('以下')
                        topSalary = str(float(word[:(postion - 3)]) * 10)
                    elif (word.find('以上') != -1):
                        # XX万以上
                        postion = word.find('以上')
                        topSalary = str(float(word[:postion - 3]) * 10)
                    else:
                        # XX万/月
                        postion = word.find('-')
                        topSalary = str(float(word[(postion + 1):(length - 7)]) * 10)

                else:
                    if (word.find('以下') != -1):
                        # XX万以下/年
                        postion = word.find('以下')
                        topSalary = str(float(word[:(postion - 3)]) / 1.2)
                    elif (word.find('以上') != -1):
                        # XX万以上一年
                        postion = word.find('以上')
                        topSalary = str(float(word[:postion - 3]) / 1.2)
                    elif (word.find('+') != -1):
                        # XX万+
                        postion = word.find('+')
                        topSalary = str(float(word[:(postion)]) / 1.2)
                    else:
                        # XX万/年
                        postion = word.find('-')
                        topSalary = word[(postion + 1):(length - 7)]
                        topSalary = str(int(topSalary) / 1.2)
            return topSalary

    def process_item(self, item, spider):
        '''
        将爬取的信息保存到mysql
        :param item:
        :param spider:
        :return: item
        '''
        # Get data from item
        job_name = item['job_name']
        company = item['company']
        address = item['address']
        salary = item['salary']

        dirty_job_name = re.compile(r'(\*|在家|试用|体验|无需|无须|试玩|红包)+')
        dirty_salary = re.compile(r'(小时|天)+')

        # clean dirty data
        if(dirty_job_name.search(str(job_name))):
            raise DropItem("Dirty data %s" % item)
        if(dirty_salary.search(str(salary))):
            raise DropItem("Dirty data %s" % item)

        # sort out data
        salary = ''.join(salary)
        item['bottomSalary'] = self.cut_word(salary, method='bottom')
        item['topSalary'] = self.cut_word(salary, method='top')

        # # Connecting with local database, change the value if not the same
        # db = pymysql.connect(
        #     host='localhost',
        #     user='root',
        #     passwd='1320',
        #     db='scrapyDB',
        #     charset='utf8',
        #     cursorclass=pymysql.cursors.DictCursor)
        # try:
        #     # open the cursor
        #     cursor = db.cursor()
        #     sql = 'INSERT INTO tb_job(job_name,company,address,salary,time)' \
        #           'VALUES ("%s", "%s", "%s", "%s", "%s")' % (job_name,company,address,salary,time)
        #     # execute the sql
        #     cursor.execute(sql)
        #     db.commit()
        # finally:
        #     # close the connection
        #     db.close()

        return item


